package com.rosien.bestby_full;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;

class CalendarAdapter extends RecyclerView.Adapter<CalendarViewHolder>
{
    private final ArrayList<String> daysOfMonth;
    private final ArrayList<Integer> itemsOfMonth;
    private final OnItemListener onItemListener;
    private final ArrayList<String> numberssub;
    private final ArrayList<String> numberssup;

    public CalendarAdapter(ArrayList<String> daysOfMonth, ArrayList<Integer> itemsOfMonth, OnItemListener onItemListener)
    {
        this.daysOfMonth = daysOfMonth;
        this.itemsOfMonth = itemsOfMonth;
        this.onItemListener = onItemListener;
        this.numberssub = new ArrayList<String>(Arrays.asList("₀", "₁", "₂", "₃", "₄", "₅", "₆", "₇", "₈", "₉"));
        this.numberssup = new ArrayList<String>(Arrays.asList("⁰","¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹"));
    }

    @NonNull
    @Override
    public CalendarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.calendar_cell, parent, false);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.height = (int) (parent.getHeight() * 0.166666666);
        return new CalendarViewHolder(view, onItemListener);
    }

    @Override
    public void onBindViewHolder(@NonNull CalendarViewHolder holder, int position)
    {
        if (itemsOfMonth.get(position) > 0) {
            String tempstring = itemsOfMonth.get(position).toString();
            String finalstring = "";
            String c;
            int index;

            for (int i = 0; i < tempstring.length(); i++){
                c = String.valueOf(tempstring.charAt(i));
                index = Integer.valueOf(c);
                finalstring+=(numberssub.get(index));
            }
            holder.dayOfMonth.setText("" + daysOfMonth.get(position) + "\n" + finalstring);
        }

        else{
            holder.dayOfMonth.setText(daysOfMonth.get(position) + "\n");
        }

    }

    @Override
    public int getItemCount()
    {
        return daysOfMonth.size();
    }

    public interface  OnItemListener
    {
        void onItemClick(int position, String dayText);
    }

}