package com.rosien.bestby_full;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button calendar;
    Button viewall;
    Button scanbar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button calendar = findViewById(R.id.calendarButton);
        Button viewall = findViewById(R.id.settingsButton);
        Button scanbar = findViewById(R.id.scanButton);

        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,CalendarActivity.class);
                startActivity(intent);
            }
        });

        viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,QueryWindow.class);
                startActivity(intent);
            }
        });

        scanbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,CalendarActivity.class);
                startActivity(intent);
            }
        });

    }


    public void credits(View view){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
        alertDialogBuilder.setTitle("Help");

        String text = "Created by: Tomi" + '\n';

        text += "Use: " + '\n';
        text += "Calendar: Open Calendar View" + '\n';
        text += '\n';
        text += "View All Items: List of items set to expire within a week" + '\n';
        text += '\n';
        text += "Scan Product: Scan product with camera instead of entering name manually." + '\n';
        alertDialogBuilder.setMessage(text);
        alertDialogBuilder.create().show();
    }
}
