package com.rosien.bestby_full;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class AddItemsActivity extends AppCompatActivity {
    //date
    private DatePickerDialog datePickerDialog;
    private Calendar date_object = Calendar.getInstance();
    private Button dateText;

    //list view
    private static ArrayList<String> item_list = new ArrayList<>();
    private static ItemRowAdapter adapter;
    private ListView itemView;

    //database
    private static SQLiteDatabase db;
    private static Cursor cur;

    public Button homeadditems;
    public Button calendaradditems;
    public Button scanadditems;
    public ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);
        dateText = (Button) findViewById(R.id.datepickerbtn);
        itemView = (ListView) findViewById(R.id.item_list);
        ItemDataBaseHelper helper = new ItemDataBaseHelper(this);
        db = helper.getWritableDatabase();

        Button homeadditems = findViewById(R.id.HomeButtonItemAdd);
        Button calendaradditems = findViewById(R.id.CalendarButtonItemAdd);
        Button scanadditems = findViewById(R.id.ScanButtonItemAdd);
        progressBar = (ProgressBar) findViewById(R.id.bar);
        progressBar.setVisibility(View.VISIBLE);

        homeadditems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddItemsActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

        calendaradditems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddItemsActivity.this,CalendarActivity.class);
                startActivity(intent);
            }
        });

        scanadditems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCredits();
            }
        });

        //function calls
        initListView();
        progressBar.setProgress(50);
        initDatePicker();
        progressBar.setProgress(100);
        progressBar.setVisibility(View.INVISIBLE);
        initDate(getIntent().getStringExtra("date"));
        if (getIntent().getBooleanExtra("added",false)){
            Toast.makeText(this, "Item added to list.", Toast.LENGTH_LONG).show();
        }
        itemView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long database_id) {
                createDialog(position);
            }
        } );

    }
    private void createDialog(int position){
        cur = db.rawQuery("SELECT * FROM " + ItemDataBaseHelper.TABLE_NAME, null);
        cur.moveToPosition(position);
        int index = cur.getColumnIndex(ItemDataBaseHelper.KEY_ID);
        String id = String.valueOf(cur.getLong(index));
        index = cur.getColumnIndex(ItemDataBaseHelper.KEY_DATE);
        String expiry = cur.getString(index);
        index = cur.getColumnIndex(ItemDataBaseHelper.KEY_NAME);
        String name = cur.getString(index);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(AddItemsActivity.this);
        alertDialogBuilder.setTitle("Detailed Item Information");

        String text = "ID: " + id + '\n';
        text += "Item Name: " + name + '\n';
        text += "Expiry Date: " + expiry;
        alertDialogBuilder.setMessage(text);
        alertDialogBuilder.create().show();



    }

    private void showCredits(){

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(AddItemsActivity.this);
        alertDialogBuilder.setTitle("Help");

        String text = "Created by: David Rosien" + '\n';
        text += "Use: " + '\n';
        text += "1. Select a date" + '\n';
        text += "2. View, Remove, Add Items";
        alertDialogBuilder.setMessage(text);
        alertDialogBuilder.create().show();



    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        db.close();
    }

    public void addNewItem(View v){
        Intent i = new Intent(AddItemsActivity.this, NewItemAddActivity.class);
//        i.putExtra("date", "04/16/2022");
        startActivity(i);


    }


    private void initListView(){
        item_list.clear();
        cur = db.rawQuery("SELECT " + ItemDataBaseHelper.KEY_NAME + " FROM " + ItemDataBaseHelper.TABLE_NAME + " WHERE " + ItemDataBaseHelper.KEY_DATE + " = ?",  new String[] {dateObjectToString()});
        cur.moveToFirst();
        while(!cur.isAfterLast() ) {
            item_list.add(cur.getString(0));
            cur.moveToNext();
        }
        adapter = new ItemRowAdapter();
        itemView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
//        String count = String.valueOf(cur.getCount()) + " " + String.valueOf(item_list.size());
//
//        Toast.makeText(this, count, Toast.LENGTH_LONG).show();
    }

    private void reloadListView(){
        item_list.clear();
        cur = db.rawQuery("SELECT " + ItemDataBaseHelper.KEY_NAME + " FROM " + ItemDataBaseHelper.TABLE_NAME + " WHERE " + ItemDataBaseHelper.KEY_DATE + " = ?",  new String[] {dateObjectToString()});
        cur.moveToFirst();
        int index;
        String name;
        while(!cur.isAfterLast() ) {
            index = cur.getColumnIndex(ItemDataBaseHelper.KEY_NAME);
            name = cur.getString(index);
            item_list.add(name);
            cur.moveToNext();
        }
        adapter.notifyDataSetChanged();
//        String count = String.valueOf(cur.getCount()) + " " + String.valueOf(item_list.size());
//        Toast.makeText(this, count, Toast.LENGTH_LONG).show();


    }

    private void initDatePicker(){

        DatePickerDialog.OnDateSetListener  dateSetListener = new DatePickerDialog.OnDateSetListener()
        {

            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day){
                changeDateObject(year,month,day);
                dateText.setText(dateObjectToString());
                reloadListView();
            }





        };

        int year = date_object.get(Calendar.YEAR);
        int month = date_object.get(Calendar.MONTH);
        int day = date_object.get(Calendar.DAY_OF_MONTH);


        datePickerDialog = new DatePickerDialog(this, AlertDialog.THEME_HOLO_LIGHT, dateSetListener, year, month, day);
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        datePickerDialog.getDatePicker().setMinDate(today.getTimeInMillis());

    }

    private void changeDateObject(int year, int month, int day){
        date_object.set(Calendar.DAY_OF_MONTH,day);
        date_object.set(Calendar.YEAR, year);
        date_object.set(Calendar.MONTH, month);

    }
    private String dateObjectToString(){
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        return format1.format(date_object.getTime());

    }

    public void initDate(String date){
        if (date == null) {
            dateText.setText(dateObjectToString());
            return;
        }
        else {
            SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
            try {
                date_object.setTime(format1.parse(date));
                dateText.setText(dateObjectToString());
                return;
            } catch (ParseException e) {

            }
            format1 = new SimpleDateFormat("yyyy-MM-dd");
            try {
                date_object.setTime(format1.parse(date));
                dateText.setText(dateObjectToString());
                this.reloadListView();
                return;
            } catch (ParseException e) {

            }

        }


    }
    public void openDatePicker(View v){
        datePickerDialog.show();

    }
    private void deleteItemWithID(long id){
        DBOperation db = new DBOperation();
        db.execute(id);
        reloadListView();
        }


    private class DBOperation extends AsyncTask<Long, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Long... longs) {
            db.execSQL("DELETE FROM " + ItemDataBaseHelper.TABLE_NAME + " WHERE " + ItemDataBaseHelper.KEY_ID + " = ?", new String[] {String.valueOf(longs[0])});

            return true;
        }
    }



    private class ItemRowAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return item_list.size();
        }

        @Override
        public String getItem(int i) {
            return item_list.get(i);
        }

        @Override
        public long getItemId(int position) {
            cur = db.rawQuery("SELECT * FROM " + ItemDataBaseHelper.TABLE_NAME, null);
            cur.moveToPosition(position);
            int index = cur.getColumnIndex(ItemDataBaseHelper.KEY_ID);
            return cur.getLong(index);
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = AddItemsActivity.this.getLayoutInflater();
            View row = inflater.inflate(R.layout.item_list_row,null);
            TextView name_text = row.findViewById(R.id.name_text);
            TextView date_text = row.findViewById(R.id.date_text);
            name_text.setText(getItem(position));
            date_text.setText(dateObjectToString());

            Button remove_btn = (Button) row.findViewById(R.id.remove_item_btn);
            remove_btn.setFocusable(false);
            remove_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    String item = getItem(position);
//                    Toast.makeText(getBaseContext(),item, Toast.LENGTH_LONG).show();
                      AlertDialog.Builder builder = new AlertDialog.Builder(AddItemsActivity.this);

                      builder.setMessage("Are you sure you want to delete this item?") //Add a dialog message to strings.xml

                            .setTitle("Confirmation")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    deleteItemWithID(getItemId(position));
//                                    Toast.makeText(getBaseContext(),getItem(position), Toast.LENGTH_LONG).show();
                                }
                            })
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // User cancelled the dialog
                                }
                            })
                            .show();






                }

            });
            return row;




        }
    }

}