package com.rosien.bestby_full;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class NewItemAddActivity extends AppCompatActivity {

    private DatePickerDialog datePickerDialog;
    private Button dateText;
    private TextView warning_text;
    private EditText name_input;
    private Calendar date_object = Calendar.getInstance();
    private static SQLiteDatabase db;
    private static Cursor cur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item_add);
        dateText = (Button) findViewById(R.id.datepickerbtn2);
        warning_text = (TextView) findViewById(R.id.input_warning_text);
        name_input = (EditText) findViewById(R.id.name_insert);
        initDatePicker();
        initDate(getIntent().getStringExtra("date"));
        name_input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                warning_text.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void afterTextChanged(Editable editable) { }
        });

        Button back = (Button) findViewById(R.id.btn_goback);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NewItemAddActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

        ItemDataBaseHelper helper = new ItemDataBaseHelper(this);
        db = helper.getWritableDatabase();


        Frag fragment = new Frag();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.frag, fragment);
        ft.commit();


    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        db.close();
    }

    private void initDatePicker(){

        DatePickerDialog.OnDateSetListener  dateSetListener = new DatePickerDialog.OnDateSetListener()
        {

            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day){
                changeDateObject(year,month,day);
                dateText.setText(dateObjectToString());

            }





        };

        int year = date_object.get(Calendar.YEAR);
        int month = date_object.get(Calendar.MONTH);
        int day = date_object.get(Calendar.DAY_OF_MONTH);


        datePickerDialog = new DatePickerDialog(this, AlertDialog.THEME_HOLO_LIGHT, dateSetListener, year, month, day);
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        datePickerDialog.getDatePicker().setMinDate(today.getTimeInMillis());

    }

    private void changeDateObject(int year, int month, int day){
        date_object.set(Calendar.DAY_OF_MONTH,day);
        date_object.set(Calendar.YEAR, year);
        date_object.set(Calendar.MONTH, month);

    }
    private String dateObjectToString(){
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        return format1.format(date_object.getTime());

    }
    public void showCredits(View v){

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(NewItemAddActivity.this);
        alertDialogBuilder.setTitle("Help");

        String text = "Created by: David Rosien" + '\n' + '\n';
        text += "Use: " + '\n';
        text += "1. Select a date" + '\n';
        text += "2. Enter the item name " + '\n';
        text += "3. Click 'Add Item' to add to DB";
        alertDialogBuilder.setMessage(text);
        alertDialogBuilder.create().show();



    }

    public void initDate(String date){
        if (date == null) {
            dateText.setText(dateObjectToString());
            return;
        }
        else {
            SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
            try {
                date_object.setTime(format1.parse(date));
                dateText.setText(dateObjectToString());
                return;
            } catch (ParseException e) {

            }
            format1 = new SimpleDateFormat("yyyy-MM-dd");
            try {
                date_object.setTime(format1.parse(date));
                dateText.setText(dateObjectToString());
                return;
            } catch (ParseException e) {

            }

        }


    }

    public void openDatePicker(View v){
        datePickerDialog.show();

    }

    public void addItem(View v){
        if (name_input.getText().toString().isEmpty()){
            warning_text.setVisibility(View.VISIBLE);
        } else {
//            addItemToDB(name_input.getText().toString());
            DBOperation o = new DBOperation();
            o.execute((name_input.getText().toString()));
            Intent i = new Intent(this, AddItemsActivity.class);
            i.putExtra("date", dateObjectToString());
            i.putExtra("added", true);

            startActivity(i);
        }

    }

    private void addItemToDB(String item_name){
        String date_key = dateObjectToString();
        ContentValues cValues = new ContentValues();
        cValues.put(ItemDataBaseHelper.KEY_NAME,item_name);
        cValues.put(ItemDataBaseHelper.KEY_DATE, date_key);
        db.insert(ItemDataBaseHelper.TABLE_NAME,"NullPlaceholder",cValues);

    }

    private class DBOperation extends AsyncTask<String, Void, Boolean> {


        @Override
        protected Boolean doInBackground(String... strings) {
            addItemToDB(strings[0]);
            return true;
        }
    }



}