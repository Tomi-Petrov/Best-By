package com.rosien.bestby_full;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class ItemDataBaseHelper extends SQLiteOpenHelper {    public static final String TABLE_NAME = "ITEMS";
    public static final String KEY_ID = "id";
    public static final String KEY_DATE = "expiry_date";
    public static final String KEY_NAME = "name";

    private static final String DATABASE_NAME = "Items.db";
    private static final int VERSION_NUM  = 4;

    private static final String DATABASE_CREATE= "create table "
            + TABLE_NAME + "("
            + KEY_ID + " integer primary key autoincrement, "
            + KEY_DATE + " text not null,"
            + KEY_NAME  + " text not null);";






    public ItemDataBaseHelper(Context ctx){
        super(ctx, DATABASE_NAME, null, VERSION_NUM);



    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        Log.w(SQLiteOpenHelper.class.getName(), "Upgrading database from version " + oldVersion + "to " + newVersion);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
}
