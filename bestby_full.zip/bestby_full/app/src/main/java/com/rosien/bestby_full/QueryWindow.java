package com.rosien.bestby_full;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.w3c.dom.CharacterData;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class QueryWindow extends AppCompatActivity {

    private Calendar date_object = Calendar.getInstance();

    private static ArrayList<String> item_list = new ArrayList<String>();
    private static ItemRowAdapter adapter;
    private ListView view;
    
    private static SQLiteDatabase db;
    private static Cursor cur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.query_list);

        view = (ListView) findViewById(R.id.listview);
        ItemDataBaseHelper idbh = new ItemDataBaseHelper(this);
        db = idbh.getWritableDatabase();

        initListView();
        Button home_button = (Button) findViewById(R.id.HomeButtonQuery);
        home_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(QueryWindow.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        db.close();
    }

    private void initListView(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        String currentDate = sdf.format(c.getTime());
        c.add(Calendar.WEEK_OF_MONTH,1);
        String expireDate = sdf.format(c.getTime());

        item_list.clear();
        //cur = db.rawQuery("SELECT " + ItemDataBaseHelper.KEY_NAME + " FROM " + ItemDataBaseHelper.TABLE_NAME + " WHERE " + ItemDataBaseHelper.KEY_DATE + " = ?",  new String[] {expireDate});
        cur = db.rawQuery("SELECT " + ItemDataBaseHelper.KEY_NAME + ", " + ItemDataBaseHelper.KEY_DATE + " FROM " + ItemDataBaseHelper.TABLE_NAME + " WHERE " + ItemDataBaseHelper.KEY_DATE + " >= ?" + " AND " + ItemDataBaseHelper.KEY_DATE + " <= ?",  new String[] {currentDate, expireDate});

        cur.moveToFirst();

        while(!cur.isAfterLast() ) {
            item_list.add(cur.getString(0));
            cur.moveToNext();
        }

        adapter = new ItemRowAdapter();
        view.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private String findDateObjectToString(String name){
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        String[] date;

        cur = db.rawQuery("SELECT " + ItemDataBaseHelper.KEY_DATE + " FROM " + ItemDataBaseHelper.TABLE_NAME + " WHERE " + ItemDataBaseHelper.KEY_NAME + " = ?", new String[]{name});

        cur.moveToFirst();

        return cur.getString(0);

    }
    

    private class ItemRowAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return item_list.size();
        }

        @Override
        public String getItem(int i) { return item_list.get(i); }

        @Override
        public long getItemId(int position) {
            cur = db.rawQuery("SELECT * FROM " + ItemDataBaseHelper.TABLE_NAME , null);
            cur.moveToPosition(position);
            int index = cur.getColumnIndex(ItemDataBaseHelper.KEY_ID);
            return cur.getLong(index);
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = QueryWindow.this.getLayoutInflater();
            View row = inflater.inflate(R.layout.list_template,null);

            TextView name_text = row.findViewById(R.id.name_text);
            TextView date_text = row.findViewById(R.id.date_text);
            name_text.setText(getItem(position));
            date_text.setText(findDateObjectToString(getItem(position)));

            return row;
        }
    }

    public void credits(View view){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(QueryWindow.this);
        alertDialogBuilder.setTitle("Help");

        String text = "Created by: Kevin" + '\n';
        text += '\n';
        text += "Use: " + '\n';
        text += "1. Lists the items that are" + '\n';
        text += " expiring within the next week." + '\n';
        alertDialogBuilder.setMessage(text);
        alertDialogBuilder.create().show();
    }


}


