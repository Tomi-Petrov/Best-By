package com.rosien.bestby_full;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

public class CalendarActivity extends AppCompatActivity implements CalendarAdapter.OnItemListener
{
    private TextView monthYearText;
    private RecyclerView calendarRecyclerView;
    private LocalDate selectedDate;

    private static ArrayList<String> item_list = new ArrayList<>();
    private static SQLiteDatabase db;
    private static Cursor cur;

    Button calendarhomebut;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_activity);
        initWidgets();
        selectedDate = LocalDate.now();
        ItemDataBaseHelper helper = new ItemDataBaseHelper(this);
        db = helper.getWritableDatabase();

        Button calendarhomebut = findViewById(R.id.HomeButtonCalendar);

        calendarhomebut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CalendarActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

        setMonthView();
    }

    private void initWidgets()
    {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView);
        monthYearText = findViewById(R.id.monthYearTV);
    }

    private void setMonthView()
    {
        monthYearText.setText(monthYearFromDate(selectedDate));
        ArrayList<String> daysInMonth = daysInMonthArray(selectedDate);
        ArrayList<Integer> itemsInMonth = itemsInMonthArray(selectedDate, daysInMonth);
        CalendarAdapter calendarAdapter = new CalendarAdapter(daysInMonth, itemsInMonth, this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 7);
        calendarRecyclerView.setLayoutManager(layoutManager);
        calendarRecyclerView.setAdapter(calendarAdapter);
    }

    private ArrayList<Integer> itemsInMonthArray(LocalDate date , ArrayList<String> daysInMonthArray)
    {

        ArrayList<Integer> itemsInMonthArray = new ArrayList<>();
        //LocalDate firstOfMonth = selectedDate.withDayOfMonth(1);
        LocalDate localdatecurrent;

        for (int i = 0; i < daysInMonthArray.toArray().length; i++){
            String currentday = daysInMonthArray.get(i);
            if (currentday.equals("")){
                itemsInMonthArray.add(0);
            }
            else{
                localdatecurrent = selectedDate.withDayOfMonth(Integer.valueOf(currentday));

                int count = 0;

                cur = db.rawQuery("SELECT " + ItemDataBaseHelper.KEY_NAME + " FROM " + ItemDataBaseHelper.TABLE_NAME + " WHERE " + ItemDataBaseHelper.KEY_DATE + " = ?",  new String[] {localdatecurrent.toString()});
                cur.moveToFirst();
                while(!cur.isAfterLast() ) {
                    count+=1;
                    cur.moveToNext();
                }

                itemsInMonthArray.add(count);
            }
        }

        return  itemsInMonthArray;
    }

    private ArrayList<String> daysInMonthArray(LocalDate date)
    {
        ArrayList<String> daysInMonthArray = new ArrayList<>();
        YearMonth yearMonth = YearMonth.from(date);

        int daysInMonth = yearMonth.lengthOfMonth();

        LocalDate firstOfMonth = selectedDate.withDayOfMonth(1);
        int dayOfWeek = firstOfMonth.getDayOfWeek().getValue();

        for(int i = 1; i <= 42; i++)
        {
            if(i <= dayOfWeek || i > daysInMonth + dayOfWeek)
            {
                daysInMonthArray.add("");
            }
            else
            {
                daysInMonthArray.add(String.valueOf(i - dayOfWeek));
            }
        }
        int count = 0;
        for (int x = 0; x < 7; x++){
            if (daysInMonthArray.get(x) == ""){
                count+=1;
            }
        }
        if (count==7){
            for (int y = 0; y < 7; y++){
                daysInMonthArray.remove(0);
            }
        }
        return  daysInMonthArray;
    }

    private String monthYearFromDate(LocalDate date)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        return date.format(formatter);
    }

    public void previousMonthAction(View view)
    {
        selectedDate = selectedDate.minusMonths(1);
        setMonthView();
    }

    public void nextMonthAction(View view)
    {
        selectedDate = selectedDate.plusMonths(1);
        setMonthView();
    }

    public void credits(View view){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(CalendarActivity.this);
        alertDialogBuilder.setTitle("Help");

        String text = "Created by: Tony" + '\n';
        text += "Use: " + '\n';
        text += "1. Select a date that you want to view, add or remove items for." + '\n';
        text += "2. A number in a date means that many items are expiring that day." + '\n';
        text += "" + '\n';



        alertDialogBuilder.setMessage(text);
        alertDialogBuilder.create().show();
    }

    @Override
    public void onItemClick(int position, String dayText)
    {
        if(!dayText.equals(""))
        {
            String message = dayText.split("\\n")[0] + ", " + monthYearFromDate(selectedDate);
            System.out.println(message);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d, MMMM yyyy", Locale.ENGLISH);
            LocalDate date = LocalDate.parse(message, formatter);
            Intent intent = new Intent(this, AddItemsActivity.class);
            intent.putExtra("date",date.toString());
            startActivity(intent);

        }
    }
}